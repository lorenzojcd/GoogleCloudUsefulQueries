package parser;

import java.util.Map;

public class RegexMap {

  private Map<String, String> regexMapping;

  public Map<String, String> getRegexMapping() {
    return regexMapping;
  }

  public void setRegexMapping(Map<String, String> regexMapping) {
    this.regexMapping = regexMapping;
  }
}
