package token;

import org.junit.jupiter.api.Test;

public class TokenTest {

  @Test
  public void test_token_1() {
    // TODO (AllenWang314): make test cases
  }

  @Test
  public void test_token_2() {
    // TODO (AllenWang314): make test cases
  }
}
