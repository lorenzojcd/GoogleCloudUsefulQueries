package token;

import org.junit.jupiter.api.Test;

public class QueryRegexTest {

  @Test
  public void test_queryRegex() {
    // TODO: continue adding tests
  }
}
