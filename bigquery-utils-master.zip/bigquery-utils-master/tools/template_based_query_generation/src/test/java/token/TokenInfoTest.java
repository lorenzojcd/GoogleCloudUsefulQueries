package token;

public class TokenInfoTest {
  // TODO (AllenWang314): make test cases
}
