package parser;

import org.junit.jupiter.api.Test;

public class KeywordsMappingTest {

  @Test
  public void test_getMapping() {
  }
}
