# SQL Extraction VS Code Extension

Displays information about where SQL queries are embedded and used in your project.

## Features

- Display query string creations.
- Display query string usages.

## Requirements

If downloaded separately from the repository,
ensure that the SQL extraction project is found in this project directory's parent folder.

## Release Notes

### 1.0.0

Initial release.
