package com.google.cloud.sqlecosystem.sqlextraction.output

data class Output(val queries: List<Query>)